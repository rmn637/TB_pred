from flask import Flask, redirect, url_for, request, render_template
import pickle
app = Flask(__name__, template_folder='mywebpages')


@app.route('/gotInfo/<val>')
def gotInfo(val):
    return render_template('nextpage.html',passedInfo=val, description="This is via rendered template")

@app.route('/test', methods=['POST', 'GET'])
def getData():
    
    if request.method == 'POST':
        sepal_length = request.form['sepal_length']
        sepal_width = request.form['sepal_width']
        petal_length = request.form['petal_length']
        petal_width = request.form['petal_width']
        naiveModel = pickle.load(open('NaiveBayesian.pkl', 'rb'))
        naiveModelPrediction = naiveModel.predict([[float(sepal_length), float(sepal_width), float(petal_length), float(petal_width)]])
        info = f"Naive Bayes Prediction: {naiveModelPrediction[0]}"
        boostingModel = pickle.load(open('boosting.pkl', 'rb'))
        boostingModelPrediction = boostingModel.predict([[float(sepal_length), float(sepal_width), float(petal_length), float(petal_width)]])
        info += f"<br>Boosting Prediction: {boostingModelPrediction[0]}"
        randomForestModel = pickle.load(open('random_forest.pkl', 'rb'))
        randomForestModelPrediction = randomForestModel.predict([[float(sepal_length), float(sepal_width), float(petal_length), float(petal_width)]])
        info += f"<br>Random Forest Prediction: {randomForestModelPrediction[0]}"
        return redirect(url_for('gotInfo', val=info))


if __name__ == '__main__':
    app.run(host='127.0.0.1',port='8080',debug=True)
