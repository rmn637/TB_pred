package com.example.myapp1.ui.theme

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.ktor.client.*
import io.ktor.client.call.body
import io.ktor.client.engine.cio.*
import io.ktor.client.request.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.statement.bodyAsText
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import com.example.myapp1.R

@Serializable
data class Assessment(
    val tuberculosis: Int = 0,
    val gender: String? = null,
    val age: Int? = null,
    val assessment_date: String? = null,
    val cough: Int? = null,
    val cold: Int? = null,
    val fever: Int? = null,
    val dizziness: Int? = null,
    val chestpain: Int? = null,
    val jointpain: Int? = null,
    val napepain: Int? = null,
    val backpain: Int? = null,
    val lossap: Int? = null,
    val sputum: Int? = null,
    val circulatory_system: Int? = null,
    val digestive_system: Int? = null,
    val endocrine: Int? = null,
    val eye_and_adnexa: Int? = null,
    val genitourinary_system: Int? = null,
    val infectious_and_parasitic: Int? = null,
    val mental: Int? = null,
    val musculoskeletal_system: Int? = null,
    val nervous_system: Int? = null,
    val pregnancy: Int? = null,
    val respiratory_system: Int? = null,
    val skin: Int? = null
)

class DashboardActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApp1Theme {
                DashboardScreen(
                    onMedFormClick = {
                        val intent = Intent(this, MedFormActivity::class.java)
                        startActivity(intent)
                    },
                    onLogout = {
                        val intent = Intent(this, LoginActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                )
            }
        }
    }
}

enum class DashboardSection(val label: String) {
    Overview("Overview"),
    Visuals("Charts"),
    Models("Models"),
    Datasets("Data")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onMedFormClick: () -> Unit,
    onLogout: () -> Unit
) {
    val medicalPrimary = Color(0xFF059669)
    val medicalPrimaryLight = Color(0xFF10B981)
    val medicalSubtle = Color(0xFFECFDF5)
    val medicalLight = Color(0xFFD1FAE5)
    val textPrimary = Color(0xFF064E3B)
    val textSecondary = Color(0xFF065F46)
    val background = Color(0xFFF0FDF4)
    val surfaceVariant = Color(0xFFF8FAFC)

    var selectedSection by remember { mutableStateOf(DashboardSection.Overview) }
    var assessments by remember { mutableStateOf<List<Assessment>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    // Fetch data on first composition
    LaunchedEffect(Unit) {
        loading = true
        error = null
        try {
            assessments = fetchAssessmentData()
        } catch (e: Exception) {
            error = "Failed to load data: ${e.localizedMessage}"
        }
        loading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Neuro-TB Dashboard",
                        fontWeight = FontWeight.Bold,
                        color = medicalPrimary,
                        fontSize = 22.sp
                    )
                },
                actions = {
                    TextButton(onClick = onLogout) {
                        Text("Logout", color = medicalPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = medicalSubtle
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = medicalSubtle,
                contentColor = medicalPrimary
            ) {
                DashboardSection.values().forEach { section ->
                    NavigationBarItem(
                        icon = {},
                        label = {
                            Text(
                                section.label,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        },
                        selected = selectedSection == section,
                        onClick = { selectedSection = section },
                        colors = NavigationBarItemDefaults.colors(
                            selectedTextColor = medicalPrimary,
                            indicatorColor = medicalPrimary,
                            unselectedTextColor = textSecondary
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onMedFormClick,
                containerColor = medicalPrimaryLight,
                contentColor = Color.White,
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add")
                Spacer(Modifier.width(8.dp))
                Text("Medical Form")
            }
        },
        containerColor = background
    ) { paddingValues ->
        if (loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (error != null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(error ?: "Unknown error", color = Color.Red)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                item {
                    when (selectedSection) {
                        DashboardSection.Overview -> OverviewSection(
                            textSecondary, medicalPrimary, medicalSubtle, medicalLight, assessments
                        )
                        DashboardSection.Visuals -> VisualsSection(
                            textPrimary, medicalLight, surfaceVariant, assessments
                        )
                        DashboardSection.Models -> ModelPerformanceSection(
                            textPrimary, textSecondary, medicalLight, surfaceVariant
                        )
                        DashboardSection.Datasets -> DatasetAnalyticsSection(
                            textPrimary, textSecondary, medicalLight, surfaceVariant
                        )
                    }
                }
            }
        }
    }
}

// --- Data Fetching ---
suspend fun fetchAssessmentData(): List<Assessment> {
    val client = HttpClient(CIO) {
        install(ContentNegotiation) { json() }
    }
    val response = client.get("http://10.0.2.2:1234/api/assessment_data")
    val bodyString = response.bodyAsText()
    println("API RESPONSE: $bodyString")
    return try {
        Json { ignoreUnknownKeys = true }
            .decodeFromString(ListSerializer(Assessment.serializer()), bodyString)
    } catch (e: Exception) {
        println("JSON parse error: ${e.message}")
        emptyList()
    }
}

// --- Overview Section ---
@Composable
fun OverviewSection(
    textSecondary: Color,
    medicalPrimary: Color,
    medicalSubtle: Color,
    medicalLight: Color,
    assessments: List<Assessment>
) {
    val totalPatients = assessments.size
    val tbCases = assessments.count { it.tuberculosis == 1 }
    val accuracy = "72%" // Replace with real value if available

    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "Dashboard Overview",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = medicalPrimary
        )
        StatCard("Total Patients", totalPatients.toString(), textSecondary, medicalPrimary, medicalSubtle, medicalLight)
        StatCard("TB Cases", tbCases.toString(), textSecondary, medicalPrimary, medicalSubtle, medicalLight)
        StatCard("Model Accuracy", accuracy, textSecondary, medicalPrimary, medicalSubtle, medicalLight)
    }
}

@Composable
fun StatCard(
    label: String,
    value: String,
    labelColor: Color,
    valueColor: Color,
    cardBg: Color,
    borderColor: Color
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(100.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = BorderStroke(1.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(label, color = labelColor, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(value, color = valueColor, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// --- Visuals Section ---
@Composable
fun VisualsSection(
    textPrimary: Color,
    medicalLight: Color,
    surfaceVariant: Color,
    assessments: List<Assessment>
) {
    // Defensive data prep for VisualsSection

    // TB vs Non-TB
    val tbCount = assessments.count { it.tuberculosis == 1 }
    val nonTbCount = assessments.count { it.tuberculosis == 0 }

    // Gender (TB only)
    val maleCount = assessments.count { it.tuberculosis == 1 && it.gender?.lowercase() == "male" }
    val femaleCount = assessments.count { it.tuberculosis == 1 && it.gender?.lowercase() == "female" }

    // Age groupings (decades, TB only)
    val tbAges = assessments.filter { it.tuberculosis == 1 }.mapNotNull { it.age }
    val nonTbAges = assessments.filter { it.tuberculosis == 0 }.mapNotNull { it.age }
    val ageRanges = (0..9).map { "${it * 10}-${it * 10 + 9}" }
    val tbAgeDist = IntArray(10)
    val nonTbAgeDist = IntArray(10)
    tbAges.forEach { age -> if (age in 0..99) tbAgeDist[age / 10]++ }
    nonTbAges.forEach { age -> if (age in 0..99) nonTbAgeDist[age / 10]++ }
    val tbAgeDistList = tbAgeDist.map { it.toFloat() }
    val nonTbAgeDistList = nonTbAgeDist.map { it.toFloat() }

    // TB likelihood by age group (%)
    val tbLikelihood = tbAgeDist.indices.map { i ->
        val total = tbAgeDist[i] + nonTbAgeDist[i]
        if (total == 0) 0f else tbAgeDist[i] * 100f / total
    }

    // Symptoms and systems (TB only) - direct property access, no reflection
    val symptomCounts = mapOf(
        "Cough" to assessments.count { it.tuberculosis == 1 && it.cough == 1 },
        "Cold" to assessments.count { it.tuberculosis == 1 && it.cold == 1 },
        "Fever" to assessments.count { it.tuberculosis == 1 && it.fever == 1 },
        "Dizziness" to assessments.count { it.tuberculosis == 1 && it.dizziness == 1 },
        "Chestpain" to assessments.count { it.tuberculosis == 1 && it.chestpain == 1 },
        "Jointpain" to assessments.count { it.tuberculosis == 1 && it.jointpain == 1 },
        "Napepain" to assessments.count { it.tuberculosis == 1 && it.napepain == 1 },
        "Backpain" to assessments.count { it.tuberculosis == 1 && it.backpain == 1 },
        "Lossap" to assessments.count { it.tuberculosis == 1 && it.lossap == 1 },
        "Sputum" to assessments.count { it.tuberculosis == 1 && it.sputum == 1 }
    )
    val systemCounts = mapOf(
        "Circulatory System" to assessments.count { it.tuberculosis == 1 && it.circulatory_system == 1 },
        "Digestive System" to assessments.count { it.tuberculosis == 1 && it.digestive_system == 1 },
        "Endocrine" to assessments.count { it.tuberculosis == 1 && it.endocrine == 1 },
        "Eye and Adnexa" to assessments.count { it.tuberculosis == 1 && it.eye_and_adnexa == 1 },
        "Genitourinary System" to assessments.count { it.tuberculosis == 1 && it.genitourinary_system == 1 },
        "Infectious and Parasitic" to assessments.count { it.tuberculosis == 1 && it.infectious_and_parasitic == 1 },
        "Mental" to assessments.count { it.tuberculosis == 1 && it.mental == 1 },
        "Musculoskeletal System" to assessments.count { it.tuberculosis == 1 && it.musculoskeletal_system == 1 },
        "Nervous System" to assessments.count { it.tuberculosis == 1 && it.nervous_system == 1 },
        "Pregnancy" to assessments.count { it.tuberculosis == 1 && it.pregnancy == 1 },
        "Respiratory System" to assessments.count { it.tuberculosis == 1 && it.respiratory_system == 1 },
        "Skin" to assessments.count { it.tuberculosis == 1 && it.skin == 1 }
    )

    // TB admissions by date (for line chart)
    val tbDateCounts = assessments.filter { it.tuberculosis == 1 && !it.assessment_date.isNullOrBlank() }
        .groupingBy { it.assessment_date!! }
        .eachCount()
        .toSortedMap()
    val dateLabels = tbDateCounts.keys.toList()
    val dateCounts = tbDateCounts.values.map { it.toFloat() }

    // --- UI ---
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Data Visualizations", fontWeight = FontWeight.Bold, fontSize = 24.sp, color = textPrimary)

        // TB vs Non-TB Pie
        Card(Modifier.fillMaxWidth().height(220.dp), colors = CardDefaults.cardColors(surfaceVariant)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("TB Cases Distribution", fontWeight = FontWeight.SemiBold)
                SimplePieChart(
                    data = listOf("Non-TB" to nonTbCount.toFloat(), "TB Positive" to tbCount.toFloat()),
                    colors = listOf(Color(0xFF36a2eb), Color(0xFFff6384)),
                    modifier = Modifier.size(120.dp)
                )
            }
        }

        // Gender Pie
        Card(Modifier.fillMaxWidth().height(220.dp), colors = CardDefaults.cardColors(surfaceVariant)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("Gender Distribution (TB Positive)", fontWeight = FontWeight.SemiBold)
                SimplePieChart(
                    data = listOf("Male" to maleCount.toFloat(), "Female" to femaleCount.toFloat()),
                    colors = listOf(Color(0xFF10B981), Color(0xFFEA580C)),
                    modifier = Modifier.size(120.dp)
                )
            }
        }

        // Age Distribution Bar
        Card(Modifier.fillMaxWidth().height(220.dp), colors = CardDefaults.cardColors(surfaceVariant)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("Age Distribution (TB Positive)", fontWeight = FontWeight.SemiBold)
                SimpleBarChart(
                    data = ageRanges.zip(tbAgeDistList),
                    barColor = Color(0xFF10B981),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                )
            }
        }

        // Symptom Bar
        Card(Modifier.fillMaxWidth().height(220.dp), colors = CardDefaults.cardColors(surfaceVariant)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("Symptoms in TB Cases", fontWeight = FontWeight.SemiBold)
                SimpleBarChart(
                    data = symptomCounts.map { it.key to it.value.toFloat() },
                    barColor = Color(0xFFE9C604),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                )
            }
        }

        // System Bar
        Card(Modifier.fillMaxWidth().height(220.dp), colors = CardDefaults.cardColors(surfaceVariant)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("System Involvement (TB Cases)", fontWeight = FontWeight.SemiBold)
                SimpleBarChart(
                    data = systemCounts.map { it.key to it.value.toFloat() },
                    barColor = Color(0xFFff6384),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                )
            }
        }

        // TB Likelihood by Age Group (Line)
        Card(Modifier.fillMaxWidth().height(220.dp), colors = CardDefaults.cardColors(surfaceVariant)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("TB Likelihood by Age Group (%)", fontWeight = FontWeight.SemiBold)
                SimpleLineChart(
                    data = ageRanges.zip(tbLikelihood),
                    lineColor = Color(0xFF059669),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                )
            }
        }
    }
}
// Helper to get Int field by name from Assessment (symptom/system fields)
fun getFieldValue(assessment: Assessment, field: String): Int? {
    return try {
        val prop = Assessment::class.members.firstOrNull { it.name == field } ?: return null
        (prop.call(assessment) as? Int)
    } catch (e: Exception) { null }
}

@Composable
fun ChartCard(title: String, chartType: String, backgroundColor: Color) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clickable { },
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(chartType, color = Color.Gray, fontSize = 14.sp)
        }
    }
}

@Composable
fun ModelPerformanceSection(
    textPrimary: Color,
    textSecondary: Color,
    medicalLight: Color,
    surfaceVariant: Color
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Model Performance", fontWeight = FontWeight.Bold, fontSize = 24.sp, color = textPrimary)
        Card(Modifier.fillMaxWidth().height(220.dp), colors = CardDefaults.cardColors(surfaceVariant)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("Confusion Matrix", fontWeight = FontWeight.SemiBold)
                Image(
                    painter = painterResource(id = R.drawable.confusionmatrix),
                    contentDescription = "Confusion Matrix",
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        // ROC Curve Image
        Card(Modifier.fillMaxWidth().height(220.dp), colors = CardDefaults.cardColors(surfaceVariant)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("ROC Curve", fontWeight = FontWeight.SemiBold)
                Image(
                    painter = painterResource(id = R.drawable.roccurve),
                    contentDescription = "ROC Curve",
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(surfaceVariant)) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Classification Report", fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = textPrimary)
                ClassificationTable(medicalLight)
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    "Key Insights",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    color = textPrimary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    "• Overall accuracy: 73%\n• Better at identifying healthy patients (81% precision)\n• Correctly identifies 68% of TB cases\n• May miss some TB cases due to 58% precision for positive cases",
                    color = textSecondary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
            }
        }
    }
}

@Composable
fun ClassificationTable(medicalLight: Color) {
    Column {
        Row(modifier = Modifier.fillMaxWidth().background(medicalLight).padding(12.dp)) {
            Text("Class", fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f))
            Text("Precision", modifier = Modifier.weight(1.5f), textAlign = TextAlign.End)
            Text("Recall", modifier = Modifier.weight(1.5f), textAlign = TextAlign.End)
            Text("F1", modifier = Modifier.weight(1.5f), textAlign = TextAlign.End)
        }

        Spacer(modifier = Modifier.height(4.dp))
        TableRow("No TB", "0.81", "0.75", "0.78")
        TableRow("Has TB", "0.58", "0.66", "0.62")
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth().background(medicalLight.copy(alpha = 0.6f)).padding(12.dp)) {
            Text("Overall Accuracy", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("72%", fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.End)
        }
    }
}

@Composable
fun TableRow(label: String, precision: String, recall: String, f1: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(12.dp)
    ) {
        Text(label, modifier = Modifier.weight(2f))
        Text(precision, modifier = Modifier.weight(1.5f), textAlign = TextAlign.End)
        Text(recall, modifier = Modifier.weight(1.5f), textAlign = TextAlign.End)
        Text(f1, modifier = Modifier.weight(1.5f), textAlign = TextAlign.End)
    }
}

@Composable
fun DatasetAnalyticsSection(
    textPrimary: Color,
    textSecondary: Color,
    medicalLight: Color,
    surfaceVariant: Color
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Dataset Analytics", fontWeight = FontWeight.Bold, fontSize = 24.sp, color = textPrimary)
        Card(Modifier.fillMaxWidth().height(220.dp), colors = CardDefaults.cardColors(surfaceVariant)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("Class Distribution", fontWeight = FontWeight.SemiBold)
                Image(
                    painter = painterResource(id = R.drawable.classdistribution),
                    contentDescription = "Class Distribution",
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Card(Modifier.fillMaxWidth().height(220.dp), colors = CardDefaults.cardColors(surfaceVariant)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("Correlation Matrix", fontWeight = FontWeight.SemiBold)
                Image(
                    painter = painterResource(id = R.drawable.correlationmatrix),
                    contentDescription = "Correlation Matrix",
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Card(Modifier.fillMaxWidth().height(220.dp), colors = CardDefaults.cardColors(surfaceVariant)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("Feature Importance", fontWeight = FontWeight.SemiBold)
                Image(
                    painter = painterResource(id = R.drawable.informationgainranking),
                    contentDescription = "Correlation Matrix",
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(surfaceVariant)) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Top Features by Information Gain", fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = textPrimary)
                InfoGainTable(medicalLight, textPrimary, textSecondary)
                Spacer(modifier = Modifier.height(16.dp))
                Text("What This Means", fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = textPrimary)
                Text(
                    "Age and cough duration are the most important factors for TB diagnosis. These features help the AI model make more accurate predictions about TB risk.",
                    color = textSecondary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
            }
        }
    }
}

@Composable
fun InfoGainTable(medicalLight: Color, textPrimary: Color, textSecondary: Color) {
    val features = listOf(
        "Age" to 0.156f,
        "Cough Duration" to 0.113f,
        "Cough Present" to 0.072f,
        "Cold Duration" to 0.033f,
        "Fever Duration" to 0.022f
    )

    Column {
        Row(modifier = Modifier.fillMaxWidth().background(medicalLight).padding(12.dp)) {
            Text("Feature", fontWeight = FontWeight.Bold, color = textPrimary, modifier = Modifier.weight(2f))
            Text("Importance Score", fontWeight = FontWeight.Bold, color = textPrimary, modifier = Modifier.weight(2f), textAlign = TextAlign.End)
        }

        features.forEach { (feature, score) ->
            Column(modifier = Modifier.padding(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text(feature, modifier = Modifier.weight(2f), color = textPrimary)
                    Text(String.format("%.3f", score), modifier = Modifier.weight(2f), color = textSecondary, textAlign = TextAlign.End)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Box(modifier = Modifier.fillMaxWidth().height(4.dp).background(Color(0xFFE5E7EB))) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(score / 0.156f)
                            .height(4.dp)
                            .background(Brush.horizontalGradient(listOf(Color(0xFF059669), Color(0xFF10B981))))
                    )
                }
            }
        }
    }
}

@Composable
fun SimplePieChart(
    data: List<Pair<String, Float>>,
    colors: List<Color>,
    modifier: Modifier = Modifier
) {
    val total = data.sumOf { it.second.toDouble() }.toFloat()
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        if (total > 0f) {
            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                var startAngle = -90f
                data.forEachIndexed { i, entry ->
                    val sweep = entry.second / total * 360f
                    drawArc(
                        color = colors[i % colors.size],
                        startAngle = startAngle,
                        sweepAngle = sweep,
                        useCenter = true,
                        size = Size(size.minDimension, size.minDimension)
                    )
                    startAngle += sweep
                }
            }
        } else {
            Text("No data", color = Color.Gray, fontSize = 14.sp)
        }
    }
}

@Composable
fun SimpleBarChart(
    data: List<Pair<String, Float>>,
    barColor: Color,
    modifier: Modifier = Modifier
) {
    val maxVal = data.maxOfOrNull { it.second } ?: 0f
    Row(
        modifier = modifier.height(120.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        if (maxVal > 0f) {
            data.forEach { (label, value) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier
                            .width(24.dp)
                            .height((value / maxVal * 100).dp)
                            .background(barColor, RoundedCornerShape(6.dp))
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(label, fontSize = 12.sp)
                }
            }
        } else {
            Text("No data", color = Color.Gray, fontSize = 14.sp)
        }
    }
}

@Composable
fun SimpleLineChart(
    data: List<Pair<String, Float>>,
    lineColor: Color,
    modifier: Modifier = Modifier
) {
    val maxVal = data.maxOfOrNull { it.second } ?: 0f
    val minVal = data.minOfOrNull { it.second } ?: 0f
    val points = data.map { it.second }
    val labels = data.map { it.first }

    Box(modifier = modifier.height(120.dp), contentAlignment = Alignment.BottomStart) {
        if (points.isNotEmpty() && maxVal > 0f) {
            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                val chartWidth = size.width
                val chartHeight = size.height - 24.dp.toPx() // leave space for labels
                val stepX = if (points.size > 1) chartWidth / (points.size - 1) else chartWidth

                for (i in 0 until points.size - 1) {
                    val x1 = i * stepX
                    val y1 = chartHeight - ((points[i] - minVal) / (maxVal - minVal).coerceAtLeast(1e-6f) * chartHeight)
                    val x2 = (i + 1) * stepX
                    val y2 = chartHeight - ((points[i + 1] - minVal) / (maxVal - minVal).coerceAtLeast(1e-6f) * chartHeight)
                    drawLine(
                        color = lineColor,
                        start = Offset(x1, y1),
                        end = Offset(x2, y2),
                        strokeWidth = 4f
                    )
                }
                for (i in points.indices) {
                    val x = i * stepX
                    val y = chartHeight - ((points[i] - minVal) / (maxVal - minVal).coerceAtLeast(1e-6f) * chartHeight)
                    drawCircle(
                        color = lineColor,
                        center = Offset(x, y),
                        radius = 6f
                    )
                }
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 100.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                labels.forEach { label ->
                    Text(
                        label,
                        fontSize = 10.sp,
                        maxLines = 1,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.widthIn(max = 40.dp)
                    )
                }
            }
        } else {
            Text("No data", color = Color.Gray, fontSize = 14.sp)
        }
    }
}