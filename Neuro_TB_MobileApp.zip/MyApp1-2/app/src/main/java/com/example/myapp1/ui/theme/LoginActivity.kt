package com.example.myapp1.ui.theme

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.myapp1.ui.theme.MyApp1Theme
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapp1.ui.theme.MyApp1Theme
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startActivity
import com.example.myapp1.ui.theme.LoginActivity
import com.example.myapp1.ui.theme.RegisterActivity

import io.ktor.client.*
import io.ktor.client.engine.cio.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.client.call.body
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.forms.submitForm
import io.ktor.serialization.kotlinx.json.*
import io.ktor.http.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.coroutines.launch

class LoginActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApp1Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFF0FDF4)
                ) {
                    LoginScreen(
                        onLoginSuccess = {
                            val intent = Intent(this, DashboardActivity::class.java)
                            startActivity(intent)
                        },
                        onRegisterClick = {
                            val intent = Intent(this, RegisterActivity::class.java)
                            startActivity(intent)
                        }
                    )
                }
            }
        }
    }
}

@Serializable
data class LoginRequest(val username: String, val password: String)

@Composable
fun LoginScreen( onLoginSuccess: () -> Unit, onRegisterClick: () -> Unit) {
    // State
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var messageType by remember { mutableStateOf("success") }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Colors
    val medicalPrimary = Color(0xFF059669)
    val medicalPrimaryLight = Color(0xFF10B981)
    val medicalPrimaryDark = Color(0xFF047857)
    val medicalLight = Color(0xFFD1FAE5)
    val medicalSubtle = Color(0xFFECFDF5)
    val textPrimary = Color(0xFF064E3B)
    val textSecondary = Color(0xFF065F46)
    val background = Color(0xFFF0FDF4)
    val borderColor = Color(0xFFA7F3D0)
    val medicalRed = Color(0xFFDC2626)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(background, medicalSubtle)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 400.dp)
                .padding(24.dp)
                .background(Color.White, RoundedCornerShape(16.dp))
                .shadow(10.dp, RoundedCornerShape(16.dp))
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Icon
            Box(
                modifier = Modifier
            )
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                "Login",
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                color = textPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Alert
            if (message != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (messageType == "success")
                                Brush.linearGradient(listOf(Color(0xFFECFDF5), Color(0xFFD1FAE5)))
                            else
                                Brush.linearGradient(listOf(Color(0xFFFEF2F2), Color(0xFFFECACA))),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(12.dp)
                ) {
                    Text(
                        text = message ?: "",
                        color = if (messageType == "success") medicalPrimaryDark else medicalRed,
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Form
            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = { Text("Username") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = medicalPrimary,
                    unfocusedBorderColor = borderColor,
                    focusedLabelColor = textPrimary,
                    unfocusedLabelColor = textPrimary
                )
            )
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = medicalPrimary,
                    unfocusedBorderColor = borderColor,
                    focusedLabelColor = textPrimary,
                    unfocusedLabelColor = textPrimary
                )
            )

            Button(
                onClick = {
                    coroutineScope.launch {
                        loading = true
                        message = null
                        try {
                            val result = loginApi(username, password)
                            if (result) {
                                message = "Login successful! Redirecting..."
                                messageType = "success"
                                onLoginSuccess()
                            } else {
                                message = "Login failed. Please check your credentials."
                                messageType = "danger"
                            }
                        } catch (e: Exception) {
                            message = "Network error. Please try again."
                            messageType = "danger"
                        }
                        loading = false
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF059669)
                ),
                enabled = !loading
            ) {
                Text("Login", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(20.dp))
            Text("or", color = textSecondary, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    "Create Account",
                    color = medicalPrimary,
                    fontSize = 14.sp,
                    modifier = Modifier.clickable { onRegisterClick() }
                )
            }
        }
    }
}

// Ktor API call
suspend fun loginApi(username: String, password: String): Boolean {
    val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json()
        }
    }
    val response = client.submitForm(
        url = "http://10.0.2.2:1234/login",
        formParameters = Parameters.build {
            append("username", username)
            append("password", password)
        }
    )
    client.close()
    // Adjust logic based on your Flask API's response
    return response.status.value == 200 || response.status.value == 302
}