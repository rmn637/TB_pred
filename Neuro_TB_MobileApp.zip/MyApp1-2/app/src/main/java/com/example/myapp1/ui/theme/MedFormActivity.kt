package com.example.myapp1.ui.theme

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.ktor.client.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.ui.platform.LocalContext
import io.ktor.client.request.forms.submitForm
import io.ktor.client.statement.bodyAsText
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

class MedFormActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApp1Theme {
                MedFormScreen(onSuccess = {
                    val intent = Intent(this, ResultActivity::class.java)
                    startActivity(intent)
                })
            }
        }
    }
}

@Serializable
data class MedFormRequest(
    val gender: String,
    val age: String,
    val cough: String,
    val coughdur: String,
    val cold: String,
    val colddur: String,
    val fever: String,
    val feverdur: String,
    val dob: String,
    // Individual symptom fields to match HTML structure
    val sputum: String = "0",
    val dizziness: String = "0",
    val chestpain: String = "0",
    val jointpain: String = "0",
    val napepain: String = "0",
    val backpain: String = "0",
    val lossap: String = "0",
    // Individual condition fields to match HTML structure
    val circulatory_system: String = "0",
    val digestive_system: String = "0",
    val endocrine: String = "0",
    val eye_and_adnexa: String = "0",
    val genitourinary_system: String = "0",
    val infectious_and_parasitic: String = "0",
    val mental: String = "0",
    val musculoskeletal_system: String = "0",
    val nervous_system: String = "0",
    val pregnancy: String = "0",
    val respiratory_system: String = "0",
    val skin: String = "0"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedFormScreen(onSuccess: () -> Unit) {
    // State variables
    val context = LocalContext.current
    var currentStep by remember { mutableIntStateOf(0) }
    var gender by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var cough by remember { mutableStateOf("") }
    var coughdur by remember { mutableStateOf("") }
    var cold by remember { mutableStateOf("") }
    var colddur by remember { mutableStateOf("") }
    var fever by remember { mutableStateOf("") }
    var feverdur by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("") }

    val symptomOptions = listOf(
        "Sputum Production", "Dizziness", "Chest Pain", "Joint Pain",
        "Nape Pain", "Back Pain", "Loss of Appetite"
    )
    val conditionOptions = listOf(
        "Circulatory System Disease", "Digestive System Disease", "Endocrine Disorder",
        "Eye and Adnexa Disease", "Genitourinary System Disease", "Infectious/Parasitic Disease",
        "Mental Health Condition", "Musculoskeletal System Disease", "Nervous System Disease",
        "Pregnancy", "Respiratory System Disease", "Skin Disease"
    )

    var symptoms by remember { mutableStateOf(List(symptomOptions.size) { false }) }
    var conditions by remember { mutableStateOf(List(conditionOptions.size) { false }) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var messageType by remember { mutableStateOf<MessageType>(MessageType.Info) }
    val coroutineScope = rememberCoroutineScope()

    val steps = listOf("Personal Info", "Primary Symptoms", "Other Symptoms", "Conditions")
    val totalSteps = steps.size

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Medical Assessment",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF065F46)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFECFDF5)
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .padding(padding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
            ) {
                // Progress and message
                ProgressIndicator(currentStep, totalSteps, steps)
                AnimatedVisibility(
                    visible = message != null,
                    enter = slideInVertically() + fadeIn(),
                    exit = slideOutVertically() + fadeOut()
                ) {
                    MessageCard(message ?: "", messageType) {
                        message = null
                    }
                }

                // Form content, scrollable, takes all available space
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    when (currentStep) {
                        0 -> PersonalInfoStep(
                            gender = gender,
                            onGenderChange = { gender = it },
                            age = age,
                            onAgeChange = { age = it.filter { c -> c.isDigit() } }
                        )
                        1 -> PrimarySymptomsStep(
                            cough = cough, onCoughChange = { cough = it },
                            coughDur = coughdur, onCoughDurChange = { coughdur = it.filter { c -> c.isDigit() } },
                            cold = cold, onColdChange = { cold = it },
                            coldDur = colddur, onColdDurChange = { colddur = it.filter { c -> c.isDigit() } },
                            fever = fever, onFeverChange = { fever = it },
                            feverDur = feverdur, onFeverDurChange = { feverdur = it.filter { c -> c.isDigit() } },
                            dob = dob, onDobChange = { dob = it }
                        )
                        2 -> OtherSymptomsStep(
                            options = symptomOptions,
                            selected = symptoms,
                            onSelectionChange = { idx, checked ->
                                symptoms = symptoms.toMutableList().apply { this[idx] = checked }
                            }
                        )
                        3 -> ConditionsStep(
                            options = conditionOptions,
                            selected = conditions,
                            onSelectionChange = { idx, checked ->
                                conditions = conditions.toMutableList().apply { this[idx] = checked }
                            }
                        )
                    }
                }

                // Navigation always at the bottom
                NavigationButtons(
                    currentStep = currentStep,
                    totalSteps = totalSteps,
                    loading = loading,
                    onPrevious = { currentStep-- },
                    onNext = {
                        if (validateCurrentStep(currentStep, gender, age, cough, cold, fever, dob)) {
                            currentStep++
                        } else {
                            message = "Please fill in all required fields before proceeding."
                            messageType = MessageType.Error
                        }
                    },
                    onSubmit = {
                        coroutineScope.launch {
                            message = null
                            if (!validateAllFields(gender, age, cough, cold, fever, dob)) {
                                message = "Please complete all required fields."
                                messageType = MessageType.Error
                                return@launch
                            }

                            loading = true
                            message = "Submitting your assessment..."
                            messageType = MessageType.Info

                            val req = MedFormRequest(
                                gender = gender,
                                age = age,
                                cough = cough,
                                coughdur = coughdur.ifEmpty { "0" },
                                cold = cold,
                                colddur = colddur.ifEmpty { "0" },
                                fever = fever,
                                feverdur = feverdur.ifEmpty { "0" },
                                dob = dob,
                                sputum = if (symptoms[0]) "1" else "0",
                                dizziness = if (symptoms[1]) "1" else "0",
                                chestpain = if (symptoms[2]) "1" else "0",
                                jointpain = if (symptoms[3]) "1" else "0",
                                napepain = if (symptoms[4]) "1" else "0",
                                backpain = if (symptoms[5]) "1" else "0",
                                lossap = if (symptoms[6]) "1" else "0",
                                circulatory_system = if (conditions[0]) "1" else "0",
                                digestive_system = if (conditions[1]) "1" else "0",
                                endocrine = if (conditions[2]) "1" else "0",
                                eye_and_adnexa = if (conditions[3]) "1" else "0",
                                genitourinary_system = if (conditions[4]) "1" else "0",
                                infectious_and_parasitic = if (conditions[5]) "1" else "0",
                                mental = if (conditions[6]) "1" else "0",
                                musculoskeletal_system = if (conditions[7]) "1" else "0",
                                nervous_system = if (conditions[8]) "1" else "0",
                                pregnancy = if (conditions[9]) "1" else "0",
                                respiratory_system = if (conditions[10]) "1" else "0",
                                skin = if (conditions[11]) "1" else "0"
                            )

                            try {
                                val result = submitMedForm(req)
                                if (result != null) {
                                    val intent = Intent(context, ResultActivity::class.java)
                                    intent.putExtra("result", result)
                                    context.startActivity(intent)
                                } else {
                                    message = "Submission failed. Please try again."
                                    messageType = MessageType.Error
                                }
                            } catch (e: Exception) {
                                message = "Error: ${e.localizedMessage}"
                                messageType = MessageType.Error
                                // Optionally show a Toast for debugging
                                Toast.makeText(context, "Exception: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                            }
                            loading = false
                        }
                    },
                    onReset = {
                        currentStep = 0
                        gender = ""; age = ""; cough = ""; coughdur = ""; cold = ""; colddur = ""
                        fever = ""; feverdur = ""; dob = ""
                        symptoms = List(symptomOptions.size) { false }
                        conditions = List(conditionOptions.size) { false }
                        message = null
                    }
                )
            }
        }
    }
}

@Composable
fun ProgressIndicator(currentStep: Int, totalSteps: Int, stepLabels: List<String>) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Step ${currentStep + 1} of $totalSteps",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF065F46)
                )
                Text(
                    stepLabels[currentStep],
                    fontSize = 14.sp,
                    color = Color(0xFF6B7280)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            LinearProgressIndicator(
                progress = { (currentStep + 1).toFloat() / totalSteps },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = Color(0xFF10B981),
                trackColor = Color(0xFFE5E7EB)
            )
        }
    }
}

enum class MessageType { Success, Error, Info }

@Composable
fun MessageCard(message: String, type: MessageType, onDismiss: () -> Unit) {
    val backgroundColor = when (type) {
        MessageType.Success -> Color(0xFFD1FAE5)
        MessageType.Error -> Color(0xFFFEE2E2)
        MessageType.Info -> Color(0xFFDCFDF7)
    }
    val textColor = when (type) {
        MessageType.Success -> Color(0xFF065F46)
        MessageType.Error -> Color(0xFF991B1B)
        MessageType.Info -> Color(0xFF0F766E)
    }
    val icon = when (type) {
        MessageType.Success -> Icons.Filled.CheckCircle
        MessageType.Error -> Icons.Filled.Close
        MessageType.Info -> Icons.Filled.Info
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable { onDismiss() },
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = message,
                color = textColor,
                fontSize = 14.sp,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun PersonalInfoStep(
    gender: String,
    onGenderChange: (String) -> Unit,
    age: String,
    onAgeChange: (String) -> Unit
) {
    StepCard(
        title = "Personal Information",
        icon = Icons.Filled.Person,
        description = "Please provide your basic information"
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            GenderDropdown(gender, onGenderChange)

            OutlinedTextField(
                value = age,
                onValueChange = onAgeChange,
                label = { Text("Age *") },
                placeholder = { Text("Enter your age") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF10B981),
                    focusedLabelColor = Color(0xFF10B981)
                )
            )
        }
    }
}

@Composable
fun PrimarySymptomsStep(
    cough: String, onCoughChange: (String) -> Unit,
    coughDur: String, onCoughDurChange: (String) -> Unit,
    cold: String, onColdChange: (String) -> Unit,
    coldDur: String, onColdDurChange: (String) -> Unit,
    fever: String, onFeverChange: (String) -> Unit,
    feverDur: String, onFeverDurChange: (String) -> Unit,
    dob: String, onDobChange: (String) -> Unit
) {
    StepCard(
        title = "Primary Symptoms",
        icon = Icons.Filled.Person,
        description = "Tell us about your main symptoms"
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
            SymptomRadioWithDuration("Cough", cough, onCoughChange, coughDur, onCoughDurChange)
            SymptomRadioWithDuration("Cold", cold, onColdChange, coldDur, onColdDurChange)
            SymptomRadioWithDuration("Fever", fever, onFeverChange, feverDur, onFeverDurChange)
            SymptomRadio("Difficulty of Breathing", dob, onDobChange)
        }
    }
}

@Composable
fun OtherSymptomsStep(
    options: List<String>,
    selected: List<Boolean>,
    onSelectionChange: (Int, Boolean) -> Unit
) {
    StepCard(
        title = "Additional Symptoms",
        icon = Icons.Filled.Add,
        description = "Select any additional symptoms you're experiencing"
    ) {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.heightIn(max = 400.dp)
        ) {
            itemsIndexed(options) { index, name ->
                CheckboxRow(
                    text = name,
                    checked = selected[index],
                    onCheckedChange = { onSelectionChange(index, it) }
                )
            }
        }
    }
}

@Composable
fun ConditionsStep(
    options: List<String>,
    selected: List<Boolean>,
    onSelectionChange: (Int, Boolean) -> Unit
) {
    StepCard(
        title = "Medical Conditions",
        icon = Icons.Filled.Info,
        description = "Select any existing medical conditions"
    ) {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.heightIn(max = 400.dp)
        ) {
            itemsIndexed(options) { index, name ->
                CheckboxRow(
                    text = name,
                    checked = selected[index],
                    onCheckedChange = { onSelectionChange(index, it) }
                )
            }
        }
    }
}

@Composable
fun StepCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 80.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color(0xFF10B981),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = title,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF065F46)
                )
            }

            Text(
                text = description,
                fontSize = 14.sp,
                color = Color(0xFF6B7280),
                modifier = Modifier.padding(bottom = 24.dp)
            )

            content()
        }
    }
}

@Composable
fun NavigationButtons(
    currentStep: Int,
    totalSteps: Int,
    loading: Boolean,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSubmit: () -> Unit,
    onReset: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        // Previous Button
        if (currentStep > 0) {
            OutlinedButton(
                onClick = onPrevious,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFF065F46)
                )
            ) {
                Text("Previous", fontWeight = FontWeight.Medium)
            }
        } else {
            OutlinedButton(
                onClick = onReset,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFF991B1B)
                )
            ) {
                Text("Reset", fontWeight = FontWeight.Medium)
            }
        }

        // Next/Submit Button
        Button(
            onClick = if (currentStep < totalSteps - 1) onNext else onSubmit,
            enabled = !loading,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF10B981),
                contentColor = Color.White
            )
        ) {
            if (loading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = Color.White,
                    strokeWidth = 2.dp
                )
            } else {
                Text(
                    text = if (currentStep < totalSteps - 1) "Next" else "Submit",
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun SymptomRadioWithDuration(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    duration: String,
    onDurationChange: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFB)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "$label *",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF374151),
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    RadioButton(
                        selected = value == "1",
                        onClick = { onValueChange("1") },
                        colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF10B981))
                    )
                    Text("Yes", modifier = Modifier.padding(end = 16.dp))
                    RadioButton(
                        selected = value == "0",
                        onClick = { onValueChange("0") },
                        colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF10B981))
                    )
                    Text("No")
                }

                OutlinedTextField(
                    value = duration,
                    onValueChange = onDurationChange,
                    label = { Text("Days") },
                    placeholder = { Text("0") },
                    singleLine = true,
                    modifier = Modifier.width(100.dp),
                    shape = RoundedCornerShape(8.dp)
                )
            }
        }
    }
}

@Composable
fun SymptomRadio(label: String, value: String, onValueChange: (String) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFB)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "$label *",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF374151),
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = value == "1",
                    onClick = { onValueChange("1") },
                    colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF10B981))
                )
                Text("Yes", modifier = Modifier.padding(end = 16.dp))
                RadioButton(
                    selected = value == "0",
                    onClick = { onValueChange("0") },
                    colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF10B981))
                )
                Text("No")
            }
        }
    }
}

@Composable
fun CheckboxRow(
    text: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) },
        colors = CardDefaults.cardColors(
            containerColor = if (checked) Color(0xFFECFDF5) else Color(0xFFF9FAFB)
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(12.dp)
        ) {
            Checkbox(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF10B981))
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = text,
                fontSize = 14.sp,
                color = Color(0xFF374151)
            )
        }
    }
}

@Composable
fun GenderDropdown(selected: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            label = { Text("Gender *") },
            placeholder = { Text("Select your gender") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF10B981),
                focusedLabelColor = Color(0xFF10B981)
            ),
            trailingIcon = {
                IconButton(onClick = { expanded = true }) {
                    Icon(
                        imageVector = Icons.Filled.ArrowDropDown,
                        contentDescription = "Select Gender",
                        tint = Color(0xFF6B7280)
                    )
                }
            }
        )

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            listOf("Male", "Female").forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onSelect(option)
                        expanded = false
                    }
                )
            }
        }
    }
}

// Validation functions
fun validateCurrentStep(
    step: Int,
    gender: String,
    age: String,
    cough: String,
    cold: String,
    fever: String,
    dob: String
): Boolean {
    return when (step) {
        0 -> gender.isNotBlank() && age.isNotBlank()
        1 -> cough.isNotBlank() && cold.isNotBlank() && fever.isNotBlank() && dob.isNotBlank()
        else -> true
    }
}

fun validateAllFields(
    gender: String,
    age: String,
    cough: String,
    cold: String,
    fever: String,
    dob: String
): Boolean {
    return gender.isNotBlank() && age.isNotBlank() &&
            cough.isNotBlank() && cold.isNotBlank() &&
            fever.isNotBlank() && dob.isNotBlank()
}

// Ktor API call (unchanged)
suspend fun submitMedForm(request: MedFormRequest): String? {
    val client = HttpClient(CIO) {
        install(ContentNegotiation) { json() }
    }
    val response = client.submitForm(
        url = "http://10.0.2.2:1234/submit_medical_form",
        formParameters = Parameters.build {
            append("gender", request.gender)
            append("age", request.age)
            append("cough", request.cough)
            append("coughdur", request.coughdur)
            append("cold", request.cold)
            append("colddur", request.colddur)
            append("fever", request.fever)
            append("feverdur", request.feverdur)
            append("dob", request.dob)
            append("sputum", request.sputum)
            append("dizziness", request.dizziness)
            append("chestpain", request.chestpain)
            append("jointpain", request.jointpain)
            append("napepain", request.napepain)
            append("backpain", request.backpain)
            append("lossap", request.lossap)
            append("circulatory_system", request.circulatory_system)
            append("digestive_system", request.digestive_system)
            append("endocrine", request.endocrine)
            append("eye_and_adnexa", request.eye_and_adnexa)
            append("genitourinary_system", request.genitourinary_system)
            append("infectious_and_parasitic", request.infectious_and_parasitic)
            append("mental", request.mental)
            append("musculoskeletal_system", request.musculoskeletal_system)
            append("nervous_system", request.nervous_system)
            append("pregnancy", request.pregnancy)
            append("respiratory_system", request.respiratory_system)
            append("skin", request.skin)
        }
    )
    if (response.status.value == 200) {
        val body = response.bodyAsText()
        val json = Json.parseToJsonElement(body).jsonObject
        val resultValue = json["result"]?.jsonPrimitive?.content
        return when (resultValue) {
            "0" -> "No TB detected"
            "1" -> "TB detected"
            else -> "Unknown result"
        }
    }
    return null
}