package com.example.myapp1.ui.theme

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.myapp1.ui.theme.MyApp1Theme
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import io.ktor.client.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.Serializable
import io.ktor.client.request.forms.*


class RegisterActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApp1Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFF0FDF4)
                ) {
                    RegisterScreen(
                        onRegisterSuccess = {
                            val intent = Intent(this, LoginActivity::class.java)
                            startActivity(intent)
                        },
                        onLoginClick = {
                            val intent = Intent(this, LoginActivity::class.java)
                            startActivity(intent)
                        }
                    )
                }
            }
        }
    }
}

@Serializable
data class RegisterRequest(
    val first_name: String,
    val last_name: String,
    val username: String,
    val password: String,
    val confirm_password: String
)

@Composable
fun RegisterScreen(
    onRegisterSuccess: () -> Unit,
    onLoginClick: () -> Unit
) {
    // State
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var messageType by remember { mutableStateOf("success") }
    var passwordStrength by remember { mutableStateOf("") }
    var passwordStrengthColor by remember { mutableStateOf(Color.Unspecified) }
    var passwordMatch by remember { mutableStateOf("") }
    var passwordMatchColor by remember { mutableStateOf(Color.Unspecified) }
    val coroutineScope = rememberCoroutineScope()

    // Colors
    val medicalPrimary = Color(0xFF059669)
    val medicalPrimaryLight = Color(0xFF10B981)
    val medicalPrimaryDark = Color(0xFF047857)
    val medicalLight = Color(0xFFD1FAE5)
    val medicalSubtle = Color(0xFFECFDF5)
    val textPrimary = Color(0xFF064E3B)
    val textSecondary = Color(0xFF065F46)
    val background = Color(0xFFF0FDF4)
    val borderColor = Color(0xFFA7F3D0)
    val medicalRed = Color(0xFFDC2626)
    val medicalOrange = Color(0xFFEA580C)

    fun checkPasswordStrength(pw: String) {
        if (pw.isEmpty()) {
            passwordStrength = ""
            passwordStrengthColor = Color.Unspecified
            return
        }
        var strength = 0
        if (pw.length >= 6) strength++
        if (pw.any { it.isLowerCase() }) strength++
        if (pw.any { it.isUpperCase() }) strength++
        if (pw.any { it.isDigit() }) strength++
        if (pw.any { !it.isLetterOrDigit() }) strength++
        when {
            strength < 3 -> {
                passwordStrength = "Weak password"
                passwordStrengthColor = medicalRed
            }
            strength < 4 -> {
                passwordStrength = "Medium strength"
                passwordStrengthColor = medicalOrange
            }
            else -> {
                passwordStrength = "Strong password"
                passwordStrengthColor = medicalPrimary
            }
        }
    }

    fun checkPasswordMatch(pw: String, confirm: String) {
        if (confirm.isEmpty()) {
            passwordMatch = ""
            passwordMatchColor = Color.Unspecified
            return
        }
        if (pw == confirm) {
            passwordMatch = "✓ Passwords match"
            passwordMatchColor = medicalPrimary
        } else {
            passwordMatch = "✗ Passwords do not match"
            passwordMatchColor = medicalRed
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(background, medicalSubtle)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 500.dp)
                .padding(24.dp)
                .background(Color.White, RoundedCornerShape(16.dp))
                .shadow(10.dp, RoundedCornerShape(16.dp))
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Icon
            Box(
                modifier = Modifier
            )
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                "Create Account",
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                color = textPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Alert
            if (message != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (messageType == "success")
                                Brush.linearGradient(listOf(Color(0xFFECFDF5), Color(0xFFD1FAE5)))
                            else
                                Brush.linearGradient(listOf(Color(0xFFFEF2F2), Color(0xFFFECACA))),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(12.dp)
                ) {
                    Text(
                        text = message ?: "",
                        color = if (messageType == "success") medicalPrimaryDark else medicalRed,
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Form grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(15.dp)
            ) {
                OutlinedTextField(
                    value = firstName,
                    onValueChange = { firstName = it },
                    label = { Text("First Name *") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = medicalPrimary,
                        unfocusedBorderColor = borderColor,
                        focusedLabelColor = textPrimary,
                        unfocusedLabelColor = textPrimary
                    )
                )
                OutlinedTextField(
                    value = lastName,
                    onValueChange = { lastName = it },
                    label = { Text("Last Name *") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = medicalPrimary,
                        unfocusedBorderColor = borderColor,
                        focusedLabelColor = textPrimary,
                        unfocusedLabelColor = textPrimary
                    )
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = { Text("Username *") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = medicalPrimary,
                    unfocusedBorderColor = borderColor,
                    focusedLabelColor = textPrimary,
                    unfocusedLabelColor = textPrimary
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = password,
                onValueChange = {
                    password = it
                    checkPasswordStrength(it)
                    checkPasswordMatch(it, confirmPassword)
                },
                label = { Text("Password *") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = medicalPrimary,
                    unfocusedBorderColor = borderColor,
                    focusedLabelColor = textPrimary,
                    unfocusedLabelColor = textPrimary
                )
            )
            if (passwordStrength.isNotEmpty()) {
                Text(
                    passwordStrength,
                    color = passwordStrengthColor,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = confirmPassword,
                onValueChange = {
                    confirmPassword = it
                    checkPasswordMatch(password, it)
                },
                label = { Text("Confirm Password *") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = medicalPrimary,
                    unfocusedBorderColor = borderColor,
                    focusedLabelColor = textPrimary,
                    unfocusedLabelColor = textPrimary
                )
            )
            if (passwordMatch.isNotEmpty()) {
                Text(
                    passwordMatch,
                    color = passwordMatchColor,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = {
                    coroutineScope.launch {
                        loading = true
                        message = null
                        if (password != confirmPassword) {
                            message = "Passwords do not match!"
                            messageType = "danger"
                            loading = false
                            return@launch
                        }
                        try {
                            val result = registerApi(
                                firstName, lastName, username, password, confirmPassword
                            )
                            if (result) {
                                message = "Registration successful! Redirecting to login..."
                                messageType = "success"
                                onRegisterSuccess()
                            } else {
                                message = "Registration failed. Please try again."
                                messageType = "danger"
                            }
                        } catch (e: Exception) {
                            message = "Network or server error. Please try again."
                            messageType = "danger"
                        }
                        loading = false
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                shape = RoundedCornerShape(8.dp),
                enabled = !loading && password == confirmPassword && password.isNotEmpty() && username.isNotEmpty() && firstName.isNotEmpty() && lastName.isNotEmpty()
            ) {
                Text("Create Account", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(20.dp))
            Text("or", color = textSecondary, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    "Already have an account? Login",
                    color = medicalPrimary,
                    fontSize = 14.sp,
                    modifier = Modifier.clickable { onLoginClick() }
                )
            }
        }
    }
}

suspend fun registerApi(
    firstName: String,
    lastName: String,
    username: String,
    password: String,
    confirmPassword: String
): Boolean {
    val client = HttpClient(CIO)
    val response = client.submitForm(
        url = "http://10.0.2.2:1234/register",
        formParameters = Parameters.build {
            append("first_name", firstName)
            append("last_name", lastName)
            append("username", username)
            append("password", password)
            append("confirm_password", confirmPassword)
        }
    )
    return response.status.value == 200 || response.status.value == 302
}