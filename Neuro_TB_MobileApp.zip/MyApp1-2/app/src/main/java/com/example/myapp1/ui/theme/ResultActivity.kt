package com.example.myapp1.ui.theme

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.myapp1.ui.theme.MyApp1Theme
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class ResultActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val result = intent.getStringExtra("result") ?: ""
        setContent {
            MyApp1Theme {
                ResultScreen(result = result)
            }
        }
    }
}

@Composable
fun ResultScreen(result: String) {
    val medicalPrimary = Color(0xFF059669)
    val medicalPrimaryDark = Color(0xFF047857)
    val background = Color(0xFFF0FDF4)
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(background)
            .padding(0.dp)
    ) {
        Card(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(32.dp)
                    .widthIn(min = 280.dp, max = 400.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Icon
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                listOf(medicalPrimary, medicalPrimaryDark)
                            ),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(40.dp)
                    )
                }
                Spacer(Modifier.height(18.dp))

                // Header
                Text(
                    "TB Assessment Results",
                    color = medicalPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp
                )
                Spacer(Modifier.height(8.dp))
                Divider(thickness = 1.dp, color = Color(0xFFE5E7EB))
                Spacer(Modifier.height(18.dp))

                // Result Section
                Text(
                    "Assessment Result",
                    fontWeight = FontWeight.Medium,
                    fontSize = 18.sp,
                    color = Color(0xFF374151)
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    when (result) {
                        "1" -> "Has TB"
                        "0" -> "No TB Detected"
                        ""  -> "No result available."
                        else -> result
                    },
                    fontWeight = FontWeight.Bold,
                    fontSize = 24.sp,
                    color = if (result == "1") Color(0xFFdc2626) else medicalPrimaryDark
                )
                Spacer(Modifier.height(32.dp))

                // Navigation Buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = {
                            val intent = Intent(context, MedFormActivity::class.java)
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = medicalPrimary),
                        modifier = Modifier.weight(1f)
                    ) { Text("Medical Form") }
                    Button(
                        onClick = {
                            val intent = Intent(context, DashboardActivity::class.java)
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = medicalPrimary),
                        modifier = Modifier.weight(1f)
                    ) { Text("Dashboard") }
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        val intent = Intent(context, LoginActivity::class.java)
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFdc2626)),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Logout") }
            }
        }
    }
}